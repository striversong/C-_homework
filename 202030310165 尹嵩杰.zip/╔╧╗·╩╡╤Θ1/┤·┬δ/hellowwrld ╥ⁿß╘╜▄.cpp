#include<iostream>
using namespace std;
int main()
{
	int age;
	cout<<"Please input your AGE:"<<endl;
	cin>>age;
	cout<<"Hello,World!I am"<<age<<endl;
	return 0;

}